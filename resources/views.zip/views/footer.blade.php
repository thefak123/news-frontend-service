<footer class="footer">
    <div class="container">
        
        <div class="row">
            <div class="col-md-12 text-center">
                <br>
                <div class="copyright">&copy; Tech Blog. Design: <a href="http://html.design">HTML Design</a>.</div>
            </div>
        </div>
    </div><!-- end container -->
</footer><!-- end footer -->